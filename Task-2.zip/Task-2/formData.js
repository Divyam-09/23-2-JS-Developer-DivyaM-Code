const formData = {
    minValue: 0,
    maxValue: 100,
};

export default formData;